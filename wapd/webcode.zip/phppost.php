<html>  
   <body>  
     
      Welcome <?php echo $_POST["username"]; ?> </br>  
      Your blood group is: <?php echo $_POST["bloodgroup"]; ?>  
  
   </body>  
</html> 