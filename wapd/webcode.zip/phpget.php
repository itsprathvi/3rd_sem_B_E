<html>  
   <body>  
     
      Welcome <?php echo $_GET["username"]; ?> </br>  
      Your blood group is: <?php echo $_GET["bloodgroup"]; ?>  
  
   </body>  
</html>